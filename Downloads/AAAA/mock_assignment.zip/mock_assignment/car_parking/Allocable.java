package mock_assignment.car_parking;

public interface Allocable {

}
