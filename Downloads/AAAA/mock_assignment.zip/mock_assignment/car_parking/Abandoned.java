package mock_assignment.car_parking;

public class Abandoned implements Allocable{
	
	private String reason;
	
	public Abandoned(String reason) {
		this.reason = reason;
	} 

}
