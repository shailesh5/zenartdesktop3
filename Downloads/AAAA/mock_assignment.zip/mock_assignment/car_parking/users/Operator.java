package mock_assignment.car_parking.users;

public class Operator implements User{
	
	private String operatorId;
	private String operatorName;
	
	public Operator(String operatorId, String operatorName) {
		this.operatorId = operatorId;
		this.operatorName = operatorName;
	}
	
	

}
