package com.coffeepoweredcrew.strategy;

public class User {
}
