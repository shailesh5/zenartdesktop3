package mock_assignment.car_parking_new;

public class ParkingSlot {
	
	private String slotId;
	private Double distance;

	public ParkingSlot(String slotId, Double distance) {
		this.slotId = slotId;
		this.distance = distance;
	}

	public String getSlotId() {
		return slotId;
	}

	public Double getDistance() {
		return distance;
	}
	
	
	
	
	
}
