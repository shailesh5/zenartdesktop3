package com.designpattern.creational.objectfactory;

public interface Poolable {
	
	//reset state
	public void reset();

}
