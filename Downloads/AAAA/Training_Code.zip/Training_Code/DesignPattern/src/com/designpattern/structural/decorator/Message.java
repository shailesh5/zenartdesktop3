package com.designpattern.structural.decorator;

public interface Message {
	public String getContent();
}
