package com.designpattern.behavioural.observer;

public interface OrderObserver {
	void updated(Order order);
}
